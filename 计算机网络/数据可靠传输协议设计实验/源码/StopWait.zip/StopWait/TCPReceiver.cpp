#include "stdafx.h"
#include "Global.h"
#include "TCPReceiver.h"
#include "Config.h"
TCPReceiver::TCPReceiver() :expectSequenceNumberRcvd(0), seqRange((1 << SEQ_BIT) / WINDOW_SIZE * WINDOW_SIZE)
{
	lastAckPkt.acknum = 0; //�ڴ��յ�����һ���������
	lastAckPkt.checksum = 0;
	lastAckPkt.seqnum = -1;	//���Ը��ֶ�
	for (int i = 0; i < Configuration::PAYLOAD_SIZE; i++) {
		lastAckPkt.payload[i] = '.';
	}
	lastAckPkt.checksum = pUtils->calculateCheckSum(lastAckPkt);
}

TCPReceiver::~TCPReceiver()
{
}

void TCPReceiver::receive(Packet &packet) {
	int checkSum = pUtils->calculateCheckSum(packet);
	if (checkSum == packet.checksum&&this->expectSequenceNumberRcvd == packet.seqnum) {
		this->expectSequenceNumberRcvd = (this->expectSequenceNumberRcvd + 1) % this->seqRange;//�ڴ��յ��ı�������++
		Message msg;
		memcpy(msg.data, packet.payload, sizeof(packet.payload));
		pns->delivertoAppLayer(RECEIVER, msg);//��Ӧ�ò�ݽ�����

		/*�ظ�Ackȷ�ϱ���*/
		lastAckPkt.acknum = this->expectSequenceNumberRcvd;
		lastAckPkt.checksum = pUtils->calculateCheckSum(lastAckPkt);
		pns->sendToNetworkLayer(SENDER, lastAckPkt);
	}
	else {
		pns->sendToNetworkLayer(SENDER, lastAckPkt);//�ط�ȷ�ϱ���
	}
}