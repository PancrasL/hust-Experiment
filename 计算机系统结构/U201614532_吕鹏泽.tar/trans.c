/* 
 * trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */
#include "cachelab.h"
#include <stdio.h>

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
    int temp0, temp1, temp2, temp3, temp4, temp5, temp6, temp7;

    int row, col, line, index;
    //temp1, temp2, temp3, temp4, temp5, temp6, temp7;
    if (M == 32 && N == 32)
    {
        /*将32×32的矩阵分为8×8的矩阵进行运算，由于b=5, cache每一行大小为32字节*/
        for (row = 0; row < N; row += 8)
            for (col = 0; col < M; col += 8)
                for (line = row; line < row + 8; line++) //访问8×8矩阵的某一行
                {
                    //从A中取出数据
                    temp0 = A[line][col + 0];
                    temp1 = A[line][col + 1];
                    temp2 = A[line][col + 2];
                    temp3 = A[line][col + 3];
                    temp4 = A[line][col + 4];
                    temp5 = A[line][col + 5];
                    temp6 = A[line][col + 6];
                    temp7 = A[line][col + 7];
                    //将数据存放到B中
                    B[col + 0][line] = temp0;
                    B[col + 1][line] = temp1;
                    B[col + 2][line] = temp2;
                    B[col + 3][line] = temp3;
                    B[col + 4][line] = temp4;
                    B[col + 5][line] = temp5;
                    B[col + 6][line] = temp6;
                    B[col + 7][line] = temp7;
                }
    }
    else if (M == 64 && N == 64)
    {
        for (row = 0; row < N; row += 8)
        {
            for (col = 0; col < M; col += 8)
            {
                for (line = row; line < row + 4; ++line)
                { //首先处理8×8矩阵的上半部分(4×8的矩阵)
                    temp0 = A[line][col + 0];
                    temp1 = A[line][col + 1];
                    temp2 = A[line][col + 2];
                    temp3 = A[line][col + 3];
                    temp4 = A[line][col + 4];
                    temp5 = A[line][col + 5];
                    temp6 = A[line][col + 6];
                    temp7 = A[line][col + 7];
                    B[col + 0][line] = temp0;
                    B[col + 1][line] = temp1;
                    B[col + 2][line] = temp2;
                    B[col + 3][line] = temp3;
                    B[col + 0][line + 4] = temp4; //临时存放
                    B[col + 1][line + 4] = temp5; //临时存放
                    B[col + 2][line + 4] = temp6; //临时存放
                    B[col + 3][line + 4] = temp7; //临时存放
                }
                for (line = 0; line < 4; line++) //Do the fantastic transformation!
                {
                    //get this row of the right-upper 4*4 block
                    temp0 = B[col + line][row + 4];
                    temp1 = B[col + line][row + 5];
                    temp2 = B[col + line][row + 6];
                    temp3 = B[col + line][row + 7];
                    //update this row to its correct tempue
                    temp4 = A[row + 4][col + line];
                    temp5 = A[row + 5][col + line];
                    temp6 = A[row + 6][col + line];
                    temp7 = A[row + 7][col + line];

                    B[col + line][row + 4] = temp4;
                    B[col + line][row + 5] = temp5;
                    B[col + line][row + 6] = temp6;
                    B[col + line][row + 7] = temp7;

                    //update the left lower 4*4 block of B
                    B[col + 4 + line][row + 0] = temp0;
                    B[col + 4 + line][row + 1] = temp1;
                    B[col + 4 + line][row + 2] = temp2;
                    B[col + 4 + line][row + 3] = temp3;
                }
                //update the right lower 4*4 block
                for (line = 4; line < 8; line++)
                    for (index = 4; index < 8; index++)
                        B[col + index][row + line] = A[row + line][col + index];
            }
        }
    }
    else
    { //分割为16×16的矩阵进行处.理
        const int T = 18;
        for (row = 0; row < 61; row += T)
            for (col = 0; col < 67; col += T)
                for (line = col; line < col + T && line < 67; line++)
                    for (index = row; index < row + T && (index < 61); index++)
                    {
                        temp0 = A[line][index];
                        B[index][line] = temp0;
                    }
    }
}

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++)
    {
        for (j = 0; j < M; j++)
        {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }
}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc);
}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++)
    {
        for (j = 0; j < M; ++j)
        {
            if (A[i][j] != B[j][i])
            {
                return 0;
            }
        }
    }
    return 1;
}
